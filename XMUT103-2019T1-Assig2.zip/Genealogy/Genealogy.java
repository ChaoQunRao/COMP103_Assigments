// This program is copyright VUW.
// You are granted permission to use it to construct your answer to a COMP103 assignment.
// You may not distribute it in any other way without permission.

/* Code for XMUT103 - 2019T1, Assignment 2
 * Name:
 * Username:
 * ID:
 */

import ecs100.*;
import java.util.*;
import java.io.*;

/** Genealogy:
 * Prints out information from a genealogical database
 */

public class Genealogy  {

    // all the people:  key is a name,  value is a Person object
    private final Map<String, Person> database = new HashMap<String, Person>();

    private String selectedName;  //currently selected name.

    private boolean databaseHasBeenFixed = false;

    /**
     * Constructor
     */
    public Genealogy() {
        loadData();
        setupGUI();
    }

    /**
     * Buttons and text field for operations.
     */
    public void setupGUI(){
        UI.addButton("Print all names", this::printAllNames);
        UI.addButton("Print all details", this::printAllDetails);
        UI.addTextField("Name", this::selectPerson);
        UI.addButton("Parent details", this::printParentDetails);
        UI.addButton("Add child", this::addChild);
        UI.addButton("Find & print Children", this::printChildren);
        UI.addButton("Fix database", this::fixDatabase);
        UI.addButton("Print GrandChildren", this::printGrandChildren);
        UI.addButton("Print Missing", this::printMissing);
        UI.addButton("Clear Text", UI::clearText);
        UI.addButton("Reload Database", this::loadData);
        UI.addButton("Quit", UI::quit);
        UI.setDivider(1.0);
    }

    /** 
     *  Load the information from the file "database.txt".
     *        Each line of the file has information about one person:
     *        name, year of birth, mother's name, father's name
     *        (note: a '-' instead of a name means  the mother or father are unknown)
     *        For each line,
     *         - construct a new Person with the information, and
     *   - add to the database map.
     */
    public void loadData() {
        try{
            Scanner sc = new Scanner(new File("database.txt"));
            // read the file to construct the Persons to put in the map
            /*# YOUR CODE HERE */

            sc.close();
            UI.println("Loaded "+database.size()+" people into the database");
        }catch(IOException e){throw new RuntimeException("Loading database.txt failed" + e);}
    }

    /** Prints out names of all the people in the database */
    public void printAllNames(){
        for (String name : database.keySet()) {
            UI.println(name);
        }
        UI.println("-----------------");
    }

    /** Prints out details of all the people in the database */
    public void printAllDetails(){
        /*# YOUR CODE HERE */

        UI.println("-----------------");
    }

    /**
     * Store value (capitalised properly) in the selectedName field.
     * If there is a person with that name currently in people,
     *  then print out the details of that person,
     * Otherwise, offer to add the person:
     * If the user wants to add the person,
     *  ask for year of birth, mother, and father
     *  create the new Person,
     *  add to the database, and
     *  print out the details of the person.
     * Hint: it may be useful to make an askPerson(String name) method
     * Hint: remember to capitalise the names that you read from the user
     */
    public void selectPerson(String value){
        selectedName = capitalise(value); 
        /*# YOUR CODE HERE */

    }

    /**
     * Print all the details of the mother and father of the person
     * with selectedName (if there is one).
     * (If there is no person with the current name, print "no person called ...")
     * If the mother or father's names are unknown, print "unknown".
     * If the mother or father names are known but they are not in
     *  the database, print "...: No details known".
     */
    public void printParentDetails(){
        /*# YOUR CODE HERE */

        UI.println("-----------------");
    }

    /**
     * Add a child to the person with selectedName (if there is one).
     * If there is no person with the selectedName,
     *   print "no person called ..." and return
     * Ask for the name of a child of the selectedName
     *  (remember to capitalise the child's name)
     * If the child is already recorded as a child of the person,
     *  print a message
     * Otherwise, add the child's name to the current person.
     * If the child's name is not in the current database,
     *   offer to add the child's details to the current database.
     *   Check that the selectedName is either the mother or the father.
     */
    public void addChild(){
        /*# YOUR CODE HERE */

        UI.println("-----------------");
    }

    /**
     * Print the number of children of the selectedName and their names (if any)
     * Find the children by searching the database for people with
     * selectedName as a parent.
     * Hint: Use the findChildren method (which is needed for other methods also)
     */
    public void printChildren(){
        /*# YOUR CODE HERE */

        UI.println("-----------------");
    }

    /**
     * Find (and return) the set of all the names of the children of
     * the given person by searching the database for every person 
     * who has a mother or father equal to the person's name.
     * If there are no children, then return an empty Set
     */
    public Set<String> findChildren(String name){
        /*# YOUR CODE HERE */

        return null;   // just so the template will compile!
    }

    /**
     * When the database is first loaded, none of the Persons will
     * have any children recorded in their children field. 
     * Fix the database so every Person's children includes all the
     * people that have that Person as a parent.
     * Hint: use the findChildren method
     */
    public void fixDatabase(){
        /*# YOUR CODE HERE */

        databaseHasBeenFixed = true;
        UI.println("Found children of each person in database\n-----------------");
    }


    /**
     * Print out all the grandchildren of the selectedName (if any)
     * Assume that the database has been "fixed" so that every Person
     * contains a set of all their children.
     * If the selectedName is not in the database, print "... is not known"
     */
    public void printGrandChildren(){
        if (!databaseHasBeenFixed) { UI.println("Database must be fixed first!");}
        if (!database.containsKey(selectedName)){
            UI.println("That person is not known");
            return;
        }
        /*# YOUR CODE HERE */

        UI.println("------------------");
    }

    /**
     * Print out all the names that are in the database but for which
     * there is no Person in the database. Do not print any name twice.
     * These will be names of parents or children of Persons in the Database
     * for which a Person object has not been created.
     */
    public void printMissing(){
        UI.println("Missing names:");
        /*# YOUR CODE HERE */

        UI.println("------------------");
    }

    /**
     * Return a capitalised version of a string
     */
    public String capitalise(String s){
        return s.substring(0,1).toUpperCase() + s.substring(1).toLowerCase();
    }


    public static void main(String[] args) throws IOException {
        new Genealogy();
    }
}
